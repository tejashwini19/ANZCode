package com.infosys.anz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnZdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnZdemoApplication.class, args);
	}

}
